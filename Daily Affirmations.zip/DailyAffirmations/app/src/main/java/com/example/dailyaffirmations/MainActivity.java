package com.example.dailyaffirmations;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private String[] quotes = {
            "You’ve got this. Hopefully.",
            "Progress is progress, even if it’s barely noticeable.",
            "At least you tried. That’s something… right?",
            "One step at a time. Even if the step is a nap.",
            "You’re doing okay. Probably.",
            "The best way to cope with your problems is to add new ones to distract yourself from the original ones.",
            "Everything happens for a reason. But what *was* the reason??",
            "Not every day is precious. Waste today. You deserve it.",
            "You're not behind. Time is an illusion.",
            "Progress, not perfection. Unless perfection is easier.",
            "Remember, you’re not the only one making mistakes. Some of us are just better at hiding it.",
            "Today’s struggle is tomorrow’s... well, probably another struggle.",
            "Motivation is like caffeine, it only lasts for a short time.",
            "Your future self will thank you. Maybe. Probably not though.",
            "Stop worrying about what other people think. I mean, have you met other people? They're awful.",
            "It’s okay to not have everything figured out. Not like anyone else does either.",
            "At least you got out of bed today. That’s something, right?",
            "Don't worry, you’ll figure it out… eventually.",
            "Let go of the past. You're holding yourself back from making new regrets.",
            "Keep going. You're closer than you think. Unless you're lost.",
            "Ask the universe for guidance. Then just go and do whatever stupid thing you were going to do anyway.",
            "Sometimes, the best thing to do is nothing. And by 'nothing,' I mean procrastinate for an extra hour.",
            "Perfection is overrated. So is getting up on time.",
            "Prioritize your mental health. Have a good cry every morning as you question everything about your life."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView quoteTextView = findViewById(R.id.quoteTextView);
        Button nextButton = findViewById(R.id.nextButton);

        final Random rand = new Random();
        final int[] colors = {
                getResources().getColor(R.color.pastel_blue),
                getResources().getColor(R.color.pastel_purple),
                getResources().getColor(R.color.pastel_yellow),
                getResources().getColor(R.color.pastel_green),
                getResources().getColor(R.color.pastel_peach),
                getResources().getColor(R.color.pastel_cream)
        };

        // Show a random quote on start
        quoteTextView.setText(quotes[rand.nextInt(quotes.length)]);
        findViewById(R.id.mainLayout).setBackgroundColor(colors[rand.nextInt(colors.length)]);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Animation fadeOut = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade_out);
                Animation fadeIn = AnimationUtils.loadAnimation(MainActivity.this, R.anim.fade_in);

                quoteTextView.startAnimation(fadeOut);

                fadeOut.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {}

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        String randomQuote = quotes[rand.nextInt(quotes.length)];
                        quoteTextView.setText(randomQuote);

                        int randomColor = colors[rand.nextInt(colors.length)];
                        findViewById(R.id.mainLayout).setBackgroundColor(randomColor);

                        quoteTextView.startAnimation(fadeIn);
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {}
                });
            }
        });
    }
}
